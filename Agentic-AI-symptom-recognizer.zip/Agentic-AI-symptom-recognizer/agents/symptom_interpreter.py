import os
from crewai import Agent
from langfuse import observe
from langfuse import Langfuse
import openai
from groq import Groq

class SymptomInterpreterAgent:
    def __init__(self, groq_api_key, langfuse_secret_key, langfuse_public_key):
        self.groq_client = Groq(api_key=groq_api_key)
        self.langfuse = Langfuse(
            secret_key=langfuse_secret_key,
            public_key=langfuse_public_key
        )

        self.agent = Agent(
            role='Medical Symptom Interpreter',
            goal='Extract and structure symptom information from user input',
            backstory="""You are a specialized medical assistant that helps patients 
            organize their symptoms before visiting a doctor. You extract key information 
            like duration, severity, affected body parts, and related symptoms.""",
            verbose=True,
            allow_delegation=False
        )

    @observe()
    def process_symptoms(self, user_input):
        """Process user symptom input and extract structured information"""

        prompt = f"""
        Analyze the following symptom description and extract structured information:

        User Input: {user_input}

        Extract and return a JSON structure with:
        - main_symptoms: list of primary symptoms mentioned
        - duration: how long symptoms have been present
        - severity: scale of 1-10 if mentioned, or descriptive terms
        - affected_areas: body parts or systems affected
        - triggers: any mentioned triggers or patterns
        - associated_symptoms: related symptoms mentioned
        - timing: when symptoms occur (morning, night, etc.)

        Return only valid JSON format.
        """

        try:
            # Use Groq API
            completion = self.groq_client.chat.completions.create(
                model="llama3-8b-8192",  # Using available Groq model
                messages=[
                    {"role": "system", "content": "You are a medical symptom analysis assistant. Return only valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=1000
            )

            result = completion.choices[0].message.content
            return result

        except Exception as e:
            error_msg = f"Error processing symptoms: {str(e)}"
            return {"error": error_msg}