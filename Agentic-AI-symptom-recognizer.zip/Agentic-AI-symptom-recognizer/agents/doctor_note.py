import os
from crewai import Agent
from langfuse import observe
from langfuse import Langfuse
from groq import Groq
import json
from datetime import datetime

class DoctorNoteAgent:
    def __init__(self, groq_api_key, langfuse_secret_key, langfuse_public_key):
        self.groq_client = Groq(api_key=groq_api_key)
        self.langfuse = Langfuse(
            secret_key=langfuse_secret_key,
            public_key=langfuse_public_key
        )

        self.agent = Agent(
            role='Medical Visit Preparation Assistant',
            goal='Create organized summaries for doctor visits',
            backstory="""You are a medical documentation assistant that helps patients 
            prepare comprehensive summaries for their doctor visits. You organize 
            information clearly and professionally.""",
            verbose=True,
            allow_delegation=False
        )

    @observe()
    def create_doctor_note(self, structured_symptoms, mapped_conditions):
        """Create a formatted doctor visit summary"""

        current_date = datetime.now().strftime("%Y-%m-%d %H:%M")

        prompt = f"""
        Create a comprehensive doctor visit summary based on:

        Structured Symptoms: {structured_symptoms}
        Mapped Conditions: {mapped_conditions}

        Create two formats:

        1. JSON format with:
        - patient_summary: organized symptom timeline
        - key_concerns: main issues to discuss
        - probable_conditions_to_discuss: conditions from mapping to bring up with doctor
        - suggested_tests_to_request: diagnostic tests that might be helpful
        - questions_for_doctor: specific questions to ask about conditions and tests
        - symptom_timeline: chronological symptom progression
        - preparation_date: {current_date}

        2. Readable paragraph format:
        - Professional summary suitable for sharing with healthcare provider
        - Include probable conditions to discuss (with disclaimers)
        - Include suggested diagnostic tests to consider
        - Clear, concise, and well-organized
        - Include timeline and severity information
        - Emphasize these are suggestions for discussion, not diagnoses

        Return as JSON with both 'json_format' and 'readable_format' fields.
        """

        try:
            completion = self.groq_client.chat.completions.create(
                model="llama3-8b-8192",
                messages=[
                    {"role": "system", "content": "You are a medical documentation assistant. Create clear, professional summaries for doctor visits. Return only valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.1,
                max_tokens=1500
            )

            result = completion.choices[0].message.content
            return result

        except Exception as e:
            error_msg = f"Error creating doctor note: {str(e)}"
            return {"error": error_msg}