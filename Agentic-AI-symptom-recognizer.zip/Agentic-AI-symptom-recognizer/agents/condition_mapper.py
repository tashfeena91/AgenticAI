import os
from crewai import Agent
from langfuse import observe
from langfuse import Langfuse
from groq import Groq
import json

class ConditionMapperAgent:
    def __init__(self, groq_api_key, langfuse_secret_key, langfuse_public_key):
        self.groq_client = Groq(api_key=groq_api_key)
        self.langfuse = Langfuse(
            secret_key=langfuse_secret_key,
            public_key=langfuse_public_key
        )

        self.agent = Agent(
            role='Medical Condition Mapper',
            goal='Map symptoms to potential general causes without diagnosing',
            backstory="""You are a medical knowledge assistant that helps identify 
            potential general causes for symptoms. You NEVER provide diagnoses, 
            but help patients understand possible areas of concern to discuss with their doctor.""",
            verbose=True,
            allow_delegation=False
        )

    @observe()
    def map_conditions(self, structured_symptoms):
        """Map structured symptoms to potential general causes"""

        prompt = f"""
        Based on the following structured symptom information, provide detailed potential medical considerations:

        Symptoms: {structured_symptoms}

        IMPORTANT DISCLAIMERS:
        - This is NOT a medical diagnosis
        - Always recommend consulting a healthcare professional
        - These are potential conditions to discuss with a doctor

        Return JSON with:
        - potential_areas: list of general body systems or areas that might be involved
        - probable_conditions: list of most likely conditions to consider (with disclaimers)
        - differential_diagnoses: other conditions that might present similarly
        - urgency_level: low/medium/high based on symptom severity
        - doctor_specialties: types of doctors who might help
        - suggested_tests: common diagnostic tests that might be helpful
        - general_advice: basic self-care suggestions
        - red_flags: symptoms that need immediate attention
        - disclaimers: important medical disclaimers

        Return only valid JSON format.
        """

        try:
            completion = self.groq_client.chat.completions.create(
                model="llama3-8b-8192",
                messages=[
                    {"role": "system", "content": "You are a medical information assistant. Never diagnose. Provide general guidance only. Return only valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                max_tokens=1200
            )

            result = completion.choices[0].message.content
            return result

        except Exception as e:
            error_msg = f"Error mapping conditions: {str(e)}"
            return {"error": error_msg}