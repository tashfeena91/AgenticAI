
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import os
from dotenv import load_dotenv
import json
from agents.symptom_interpreter import SymptomInterpreterAgent
from agents.condition_mapper import ConditionMapperAgent
from agents.doctor_note import DoctorNoteAgent

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI(
    title="Symptom Checker API",
    description="AI-powered symptom analysis and doctor visit preparation",
    version="1.0.0"
)

# Security
security = HTTPBearer()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Get API keys
LANGFUSE_SECRET_KEY = os.environ.get('Langfuse_secretkey')
LANGFUSE_PUBLIC_KEY = os.environ.get('Langfuse_publickey')
GROQ_API_KEY = os.environ.get('Groq_key')
API_KEY = os.environ.get('API_KEY', 'demo-api-key-123')  # Add this to your secrets

# Initialize agents
symptom_interpreter = SymptomInterpreterAgent(
    GROQ_API_KEY, LANGFUSE_SECRET_KEY, LANGFUSE_PUBLIC_KEY
)
condition_mapper = ConditionMapperAgent(
    GROQ_API_KEY, LANGFUSE_SECRET_KEY, LANGFUSE_PUBLIC_KEY
)
doctor_note_agent = DoctorNoteAgent(
    GROQ_API_KEY, LANGFUSE_SECRET_KEY, LANGFUSE_PUBLIC_KEY
)

# Request/Response models
class SymptomRequest(BaseModel):
    symptoms: str
    user_id: Optional[str] = None

class SymptomResponse(BaseModel):
    success: bool
    structured_symptoms: Optional[dict] = None
    mapped_conditions: Optional[dict] = None
    doctor_note: Optional[dict] = None
    error: Optional[str] = None

# Security dependency
async def verify_api_key(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if credentials.credentials != API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return credentials.credentials

# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "symptom-checker-api"}

# Main symptom analysis endpoint
@app.post("/analyze-symptoms", response_model=SymptomResponse)
async def analyze_symptoms(
    request: SymptomRequest,
    api_key: str = Depends(verify_api_key)
):
    """
    Analyze user symptoms and provide structured medical information
    """
    try:
        if not request.symptoms.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Symptoms description cannot be empty"
            )
        
        # Step 1: Interpret symptoms
        structured_symptoms = symptom_interpreter.process_symptoms(request.symptoms)
        
        # Step 2: Map to conditions
        mapped_conditions = condition_mapper.map_conditions(structured_symptoms)
        
        # Step 3: Create doctor note
        doctor_note = doctor_note_agent.create_doctor_note(
            structured_symptoms, mapped_conditions
        )
        
        # Parse JSON responses safely
        def safe_json_parse(json_string):
            try:
                if isinstance(json_string, str):
                    if '```json' in json_string:
                        json_string = json_string.split('```json')[1].split('```')[0].strip()
                    elif '```' in json_string:
                        json_string = json_string.split('```')[1].split('```')[0].strip()
                    return json.loads(json_string)
                return json_string
            except:
                return {"raw_response": json_string}
        
        return SymptomResponse(
            success=True,
            structured_symptoms=safe_json_parse(structured_symptoms),
            mapped_conditions=safe_json_parse(mapped_conditions),
            doctor_note=safe_json_parse(doctor_note)
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing symptoms: {str(e)}"
        )

# Get structured symptoms only
@app.post("/interpret-symptoms")
async def interpret_symptoms(
    request: SymptomRequest,
    api_key: str = Depends(verify_api_key)
):
    """
    Extract structured information from symptom description
    """
    try:
        result = symptom_interpreter.process_symptoms(request.symptoms)
        return {"success": True, "structured_symptoms": result}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error interpreting symptoms: {str(e)}"
        )

# API documentation
@app.get("/")
async def root():
    return {
        "message": "Symptom Checker API",
        "endpoints": {
            "/health": "Health check",
            "/analyze-symptoms": "Complete symptom analysis",
            "/interpret-symptoms": "Symptom interpretation only",
            "/docs": "API documentation"
        },
        "authentication": "Bearer token required"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
